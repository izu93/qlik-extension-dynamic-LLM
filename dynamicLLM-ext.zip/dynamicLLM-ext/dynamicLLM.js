define(['./dist/dynamicLLM'], (supernova) => supernova);
